"""Routes module - Rotas da API"""

from . import characters, health

__all__ = ["characters", "health"] 