"""API module - Rotas da aplicação"""

from .routes import characters, health

__all__ = ["characters", "health"] 