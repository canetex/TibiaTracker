"""
Tibia Tracker Backend Application
================================

Módulo principal da aplicação backend.
"""

__version__ = "1.0.0"
__author__ = "Tibia Tracker Team" 